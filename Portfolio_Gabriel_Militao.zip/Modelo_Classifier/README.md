
# Modelo de Classificação de Cancelamento de Clientes

Neste projeto, criamos um modelo de classificação utilizando o algoritmo Random Forest para prever o cancelamento de clientes em uma base de dados de telecomunicações.

## Tecnologias
- Python
- Scikit-learn
- Pandas
