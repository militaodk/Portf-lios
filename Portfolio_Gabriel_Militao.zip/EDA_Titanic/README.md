
# Análise Exploratória de Dados - Titanic Dataset

Este projeto realiza uma análise exploratória no dataset público do Titanic. A análise inclui visualizações sobre as características dos passageiros e fatores que influenciaram a sobrevivência.

## Tecnologias
- Python
- Pandas
- Seaborn
- Matplotlib
