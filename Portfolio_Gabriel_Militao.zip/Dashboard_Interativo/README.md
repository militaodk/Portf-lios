
# Dashboard Interativo - BI em Python

Este projeto apresenta um dashboard interativo utilizando dados de vendas, permitindo visualizações dinâmicas de KPIs importantes.

## Tecnologias
- Python
- Plotly Dash
