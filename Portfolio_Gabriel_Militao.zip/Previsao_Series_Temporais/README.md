
# Previsão de Séries Temporais - Vendas

Este projeto usa o Facebook Prophet para prever vendas futuras com base em séries temporais de dados de vendas.

## Tecnologias
- Python
- Prophet
- Matplotlib
